package sample;

import java.util.Random;

public class Main {
    public static Random rd = new Random();
    public static int[] pole;


    public static void main(String[] args) {
        int[] pole = {1,1,1,1};
        pole[0] = rd.nextInt(9);
        pole[1] = rd.nextInt(9);
        pole[2] = rd.nextInt(9);
        pole[3] = rd.nextInt(9);
        System.out.println(pole[0]);
        System.out.println(pole[1]);
        System.out.println(pole[2]);
        System.out.println(pole[3] + "\nJejich součet se rovná " + (pole[0]+pole[1]+pole[2]+pole[3]));
    }
}
