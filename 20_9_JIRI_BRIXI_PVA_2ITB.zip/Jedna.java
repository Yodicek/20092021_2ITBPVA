package sample;

public class Main {

    public static int[] pole = {8, 4, 5, 3};

    public static void main(String[]args){
        DejVlevo();
    }

    public static void DejVlevo(){
        System.out.println("[" + pole[0] + "" + pole[1] + "" + pole[2] + "" + pole[3] + "]");
        System.out.println("[" + pole[1] + "" + pole[2] + "" + pole[3] + "" + pole[0] + "]");
        System.out.println("[" + pole[2] + "" + pole[3] + "" + pole[0] + "" + pole[1] + "]");
        System.out.println("[" + pole[3] + "" + pole[0] + "" + pole[1] + "" + pole[2] + "]");
    }

}

